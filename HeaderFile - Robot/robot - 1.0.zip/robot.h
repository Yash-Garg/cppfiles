#define Destination_String dest
#define Source_String src
#include <iostream>
#include <windows.h>
#include <fstream>
#include <string.h>
#include <conio.h>
#include <cstdio>
#include <math.h>
using namespace std;

char Alpha[26], Alpha_B[26], E_Alpha[26], E_Alpha_B[26], file[10000][10000], PassKey[10000], line[500], line2[500];
char list1[][2]={"a"};
char list2[][3]={"if","of","to","at","on","in","is","no","so","ah","do","am"};
fstream fin, fout, fin_p;
int n=0, n_num=0, j=0, n_lines=0, c1=0, c2=0, cN=0, b=-1;
int n_terms_1=1, n_terms_2=12;

void gotoXY(int, int);

char* conv_to_char(int);
int conv_to_int(char*);
int pass_entry(char*, char, int);
void open_run(char*, char*);
char* select_file(char*, int);
void app_string(char*, char*);
void end_run(char*);
void encrypt(char*, char*, char*);
void decrypt(char*, char*, char*);
char* decrypt_brute(char*, char*, char*);
int wordbreak(char[][500], char*);
void typeout(char*, char, int);


void app_string(char* Destination_String, char* Source_String)
{
	int i=0, j=0;
	i=strlen(dest);
	while(j<strlen(src))
	{
		dest[i]=src[j];
		i++;
		j++;
	}
	dest[i]='\0';
	return;
}

char* select_file(char* location_var, int type)
{
	int k=0;
	int l=0;
	int t=0;
	l=strlen(location_var);
	if(location_var[l-1]=='/'||location_var[l-1]=='\\')
	{
		location_var[l]='*';
	}
	else
	{
		if(location_var[l-1]!='*')
		{
			location_var[l]='/';
			location_var[l+1]='*';
		}	
	}
	char file_list[500][260];
	int selection=1;
	char selection_temp[4];
	for(int i=0; i<500; i++)
	{
		for(int j=0; j<260; j++)
		{
			file_list[i][j]='\0';
		}
	}
	strcpy(file_list[0], "<<Use this folder>>");
	WIN32_FIND_DATA file;
	HANDLE c_file=FindFirstFile(location_var, &file);
	if(c_file!=INVALID_HANDLE_VALUE)
	{
		FindNextFile(c_file, &file);
		int i=0;
		do
		{
			if(((file.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN)==0)||((file.dwFileAttributes & FILE_ATTRIBUTE_SYSTEM)==0))
			{
				if(type==0)
				{
					i++;
					strcpy(file_list[i], file.cFileName);
					//All
				}
				else
				{
					if(type==1)
					{
						strcpy(file_list[i], file.cFileName);
						i++;
						//Files	
					}
					else
					{
						if(type==2)
						{
							if(file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
							{
								i++;
								strcpy(file_list[i], file.cFileName);
								//Folders only
							}
						}
						else
						{
							cerr<<"Function Error: Invalid Search Type";
							Sleep(1000);
							exit(1);
						}
					}
				}
			}
		}while(FindNextFile(c_file, &file));
		
		FindClose(c_file);
		k=0;
		while(file_list[k][0]!='\0')
		{
			k++;
		}
	}
	
	if(type==1)
	{
		k++;
	}
	
	if(k>1)
	{
		k=0;
		cout<<endl<<endl<<"Current location: ";
		for(int m=0; m<(strlen(location_var)-1); m++)
		{
			cout<<location_var[m];
		}cout<<endl<<endl;
		
		while(file_list[k][0]!='\0')
		{
			cout<<"\t"<<k<<": "<<file_list[k]<<endl;
			k++;
		}
		cout<<endl<<"Enter the number of the folder you want to open: ";
		cin.getline(selection_temp, 4);
		if(strlen(selection_temp)==0||(selection_temp[0]==' '))
		{
			cerr<<"Invalid Option";
			select_file(location_var, type);
		}
		for(int h=0; h<strlen(selection_temp); h++)
		{
			if(selection_temp[h]<'0'||selection_temp[h]>'9')
			{
				cerr<<"Invalid Option";
				select_file(location_var, type);
			}
		}
		selection=conv_to_int(selection_temp);
		if(selection>k||selection<0)
		{
			cerr<<"Invalid Option";
			select_file(location_var, type);
		}
		if(selection==0&&(!(type==1)))
		{
			l=strlen(location_var);
			location_var[l-1]='\0';
			return location_var;
		}
		else
		{
			l=strlen(location_var);
			location_var[l-1]='\0';
			app_string(location_var, file_list[selection]);
			app_string(location_var, "/");
			select_file(location_var, type);
		}
	}
	
	l=strlen(location_var);
	if(location_var[l-1]=='*'&&location_var[l-2]=='/')
	{
		location_var[l-2]='\0';
	}
	else
	{
		if(location_var[l-1]=='/')
		{
			location_var[l-1]='\0';
		}
	}
	return location_var;
}

int pass_entry(char* password_array, char hide_char, int max_length)
{
	char pwd[max_length+2];
	for(int i=0; i<=max_length+1; i++)
	{
		pwd[i]='\0';
	}
	
	int i=0;
    while(1)
    {
    	pwd[i]=getch();
    	if(i<max_length)
    	{  	
			if(pwd[i]==13)
    		{
    			pwd[i]='\0';
   	 		
				if(strlen(pwd)==0)
   		 		{
    				return 0;
				}
				cout<<endl;
				
    			break;
			}
			else
			{
				if(pwd[i]==8)
				{
					if(i<=0)
					{
						i=-1;
						pwd[i]='\0';
					}
					else
					{
						cout<<"\b \b";
						pwd[i]='\0';
						i-=2;
					}
				}
				else
				{
					if(hide_char==0)
					{
						cout<<pwd[i];
					}
					else
					{
						cout<<hide_char;
					}
				}
			}
			i++;
		}
		else
		{
			if(pwd[i]==13)
			{
				pwd[i]=='\0';
				cout<<endl;
				break;
			}
			else
			{
				if(pwd[i]==8)
				{
					cout<<"\b \b";
					pwd[i]='\0';
					i-=1;
				}
				else
				{
					continue;
				}
			}
		}
    }
	
	for(int i=0; i<max_length; i++)
	{
		password_array[i]=pwd[i];
	}
	password_array[i]='\0';
	
	return 1;
}

void open_run(char* input_file, char* password)
{
	n=0;
	n_num=0;
	j=0;
	n_lines=0;
	fin.open(input_file, ios::in);
	fin.seekg(0, ios::end);
	if(!fin||(fin.tellg()==0))
	{
		cerr<<"Input file is either empty or doesnt exist!!";
		Sleep(1000);
		exit(1);
	}
	fin.clear();
	fin.seekg(0, ios::beg);
	while(fin.getline(line, 500))
	{
		n_lines++;
	}
	fin.clear();
	fin.seekg(0, ios::beg);
	
	for(int i=0; i<strlen(PassKey); i++)
	{
		PassKey[i]='\0';
	}
	fin_p.open(password, ios::in);
	fin_p.seekg(0, ios::end);
	if((!fin_p)||(fin_p.tellg()==0))
	{
		strcpy(PassKey, password);
	}
	else
	{
		int m=0;
		while(fin_p.getline(line2, 500))
		{
			int i=0;
			while(i<strlen(line2))
			{
				PassKey[m]=line2[i];
				i++;
				m++;
			}
		}
	}
	
	
	for(int i=0; i<26; i++)
	{
		Alpha[i]=char('a'+i);	//List of small alphabets
	}
	
	for(int i=0; i<26; i++)
	{
		Alpha_B[i]=char('A'+i);		//List of capital alphabets
	}
	
	for(int i=0; i<26; i++)
	{
		E_Alpha[i]=Alpha[i];	//Initializing list of Encrypted Alphabets
	}
	
	//Getting shift from PassKey
	for(int i=0; i<strlen(PassKey); i++)
	{
		if(PassKey[i]>=48&&PassKey[i]<=57)
		{
			n+=(int(PassKey[i])-48);
		}
	}
	
	//shift in caeser cipher can only be between 1 and 25
	n_num=n;
	n=n%26;
	if(n==0)
	{
		n=1;
	}
	n_num=n_num%10;
	if(n_num==0)
	{
		n_num=1;
	}
	
	//Eliminating Special Characters
	for(int i=0; i<strlen(PassKey); i++)	
	{
		if(i==strlen(PassKey))
		{
			PassKey[i]='\0';	//Creating new ending (if required)
			break;
		}
		else
		{
			if(!((PassKey[i]>=65&&PassKey[i]<=90)||(PassKey[i]>=97&&PassKey[i]<=122)))		//Spaces, numbers and symbols will be deleted 
			{
				j=i;
				while(j<strlen(PassKey))
				{
					PassKey[j]=PassKey[j+1];	//Shifting all terms back
					j++;
				}
				i-=1;	//Compensating for lost term
			}
		}
	}
	
	//Converting to Small
	for(int i=0; i<strlen(PassKey); i++)
	{
		if(PassKey[i]>=65&&PassKey[i]<=90)
		{
			PassKey[i]=PassKey[i]+32;	//Making PassKey to all small alphabets
		}
	}
	
	//Eliminating Repetition
	for(int i=0; i+1<strlen(PassKey); i++)
	{
		for(int k=1; (i+k)<strlen(PassKey); k++)
		{
			if(PassKey[i]==PassKey[i+k])	//Repeated Characters
			{
				j=k+i;
				while(j<=strlen(PassKey))
				{
					if(j==strlen(PassKey))
					{
						PassKey[j-1]='\0';	//Ending of PassKey
					}
					else
					{
						PassKey[j]=PassKey[j+1];	//Eliminating Repitition
					}
					j++;
				}
				i-=1;	//Compensating for lost term
			}
		}
	}
	
	for(int i=0; i<strlen(PassKey); i++)
	{
		E_Alpha[i]=PassKey[i];	//Encrypted List starts with the PassKey
	}
	
	//Filling up Encrypted Alphabet List
	j=0;
	for (int i=strlen(PassKey); i<26; i++)
	{
		int counter=0;
		for(int k=0; k<strlen(PassKey); k++)
		{
			if(Alpha[j]==PassKey[k])	//Checking for Repition while filling up Encrypted Alphabet List
			{
				counter++;
			}
		}
		if(!(counter==1))
		{
			E_Alpha[i]=Alpha[j];	//Fill Alphabet if not repeated
		}
		else
		{
			i-=1;	//Skip if Repeated
		}
		j++;	//Alphabet list must keep progressing
	}
	
	for(int i=0; i<26; i++)
	{
		E_Alpha_B[i]=char(E_Alpha[i]-32);		//Making Encrypted Alphabets to all Capital Alphabets
	}
	
	j=0;
	for(; j<10000; j++)
	{
		for(int i=0; i<10000; i++)
		{
			file[j][i]='\0';
		}
	}
	
	return;
}

void end_run(char* output_file)
{
	fout.open(output_file, ios::out | ios::trunc);
	if(!fout)
	{
		cerr<<"The output file did not open";
		Sleep(1000);
		exit(1);
	}
	
	j=0;
	while(j<n_lines)
	{
		for(int i=0; i<strlen(file[j]); i++)
		{
			fout<<file[j][i];
			//cout<<file[j][i];
		}
		fout<<endl;
		j++;
	}
	fout.close();
	
	return;
}

void decrypt(char* input_file, char* output_file, char* password)
{
	open_run(input_file, password);
	
	//De-Encrypting File
	j=0;
	while(fin.getline(line, 500))
	{
		int i=0;
		while(i<strlen(line))
		{
			for (int k=0; k<26; k++)
			{
				if(line[i]==E_Alpha[k])
				{
					line[i]=Alpha[k];		//Replacing matching small Encrypted alphabets with respective small alphabets
					break; 																														// Ver 2.2
				}
				else
				{
					if(line[i]==E_Alpha_B[k])
					{
						line[i]=Alpha_B[k];	//Replacing matching Encrypted capital alphabets with respective capital alphabets
						break; 																													// Ver 2.2
					}
				}
			}
			file[j][i]=line[i];
			i++;
		}
		j++;
	}
	fin.clear();
	fin.seekg(0, ios::beg);
	
	//De-Caeser Cipher
	j=0;
	while(j<n_lines)
	{
		int i=0;
		while(i<strlen(file[j]))
		{
			if(file[j][i]>'a'-1&&file[j][i]<'z'+1)
				{
				if(file[j][i]-n>'a'-1)
				{
					file[j][i]=char(file[j][i]-n);	//If shift is between a & z, output the shift
				}
				else
				{
					file[j][i]=char(file[j][i]-n+26);	//If shift goes beyond a, go back to z
				}
			}
			else
			{
				if(file[j][i]>'A'-1&&file[j][i]<'Z'+1)
				{
					if(file[j][i]-n>'A'-1)
					{
						file[j][i]=char(file[j][i]-n);	//If the shift is between A & Z, output the shift
					}
					else
					{
						file[j][i]=char(file[j][i]-n+26);	//If shift goes beyond A, go back to Z
					}
				}
				else
				{
					if(file[j][i]>='0'&&file[j][i]<='9')
					{
						if(char(file[j][i]-n_num)>='0')
						{
							file[j][i]=char(file[j][i]-n_num);
						}
						else
						{
							file[j][i]=char(file[j][i]-n_num+10);
						}
					}
					else
					{
						file[j][i]=char(file[j][i]);	//Just output the Special Characters
					}
				}
			}
			i++;
		}
		j++;
	}
	fin.close();
	
	end_run(output_file);
}

void encrypt(char* input_file, char* output_file, char* password)
{
	open_run(input_file, password);
	
	//Caeser Cipher
	j=0;
	while(fin.getline(line, 500))
	{
		int i=0;
		while(i<strlen(line))
		{
			if(line[i]>'a'-1&&line[i]<'z'+1)
				{
				if(line[i]+n<'z'+1)
				{
					file[j][i]=char(line[i]+n);	//If shift is between a & z, output the shift
				}
				else
				{
					file[j][i]=char(line[i]+n-26);	//If shift goes beyond z, go back to a
				}
			}
			else
			{
				if(line[i]>'A'-1&&line[i]<'Z'+1)
				{
					if(line[i]+n<'Z'+1)
					{
						file[j][i]=char(line[i]+n);	//If the shift is between A & Z, output the shift
					}
					else
					{
						file[j][i]=char(line[i]+n-26);	//If shift goes beyond Z, go back to A
					}
				}
				else
				{
					if(line[i]>='0'&&line[i]<='9')
					{
						if(char(line[i]+n_num)<='9')
						{
							file[j][i]=char(line[i]+n_num);
						}
						else
						{
							file[j][i]=char(line[i]+n_num-10);
						}
					}
					else
					{
						file[j][i]=char(line[i]);	//Just output the Special Characters
					}
				}
			}
			i++;
		}
		j++;
	}
	fin.clear();
	fin.seekg(0, ios::beg);
	
	//Encrypting File
	j=0;
	while(fin.getline(line, 500))
	{
		int i=0;
		while(i<strlen(line))
		{
			for (int k=0; k<26; k++)
			{
				if(file[j][i]==Alpha[k])
				{
					file[j][i]=E_Alpha[k];		//Replacing matching small alphabets with respective Encrypted alphabets
					break; 																														// Ver 2.2
				}
				else
				{
					if(file[j][i]==Alpha_B[k])
					{
						file[j][i]=E_Alpha_B[k];	//Replacing matching capital alphabets with respective Encrypted capital alphabets
						break; 																													// Ver 2.2
					}
				}
			}
			i++;
		}
		j++;
	}
	fin.close();
	
	end_run(output_file);
}

int wordbreak(char partial_word_list[][500], char* partial_words)
{
	int count=0;
	for(int i=0; i<strlen(partial_words); i++)
	{
		if(partial_words[i]==';')
		{
			count++;
		}
	}
	count++;
	int j=0, k=0, i=0;
	//partial_word_list=new char[count][500];
	while(i<strlen(partial_words))
	{
		if(partial_words[i]==';')
		{
			j++;
			k=-1;
		}
		else
		{
			partial_word_list[j][k]=partial_words[i];
		}
		i++;
		k++;
	}
	return count;
}

char* decrypt_brute(char* input_location, char* wordlist_location, char* partials="\0")
{
	char* Output_Save;
	int n_words_part=1;
	for(int i=0; i<strlen(partials); i++)
	{
		if(partials[i]==';')
		{
			n_words_part++;
		}
	}
	char partials_list[n_words_part][500];
	for(int i=0; i<n_words_part; i++)
	{
		for(int j=0; j<500; j++)
		{
			partials_list[i][j]='\0';
		}
	}
	wordbreak(partials_list, partials);
	
	for(int i=0; i<n_words_part; i++)
	{
		if(strlen(partials_list[i])<4&&strlen(partials_list[i])!=0)
		{
			return "#";
		}
	}
	
	for(int i=0; i<n_words_part; i++)
	{
		for(int j=0; j<strlen(partials_list[i]); j++)
		{
			if(partials_list[i][j]>=65&&partials_list[i][j]<=90)
			{
				partials_list[i][j]+=32;
			}
		}
	}
	
	char line[500], word[25];
	fstream fin, fin2, fin3;
	fin.open(input_location, ios::in);
	fin.seekg(0, ios::end);
	if(!fin||(fin.tellg()==0))
	{
		cerr<<"The input file did not open";
		Sleep(1000); 	//Animation
		exit(1);
	}
	fin.clear();
	fin.seekg(0, ios::beg);
	
	fin2.open(wordlist_location, ios::in);
	fin2.seekg(0, ios::end);
	
	if(!fin2||(fin2.tellg()==0))
	{
		cerr<<"The wordlist did not open";
		Sleep(1000); //Animation
		exit(1);
	}
	fin2.clear();
	fin2.seekg(0, ios::beg);
	
	while(fin2.getline(line, 500))
	{
		if(line[0]=='/')
		{
			if(line[1]=='/')
			{
				continue;
			}
		}
		cN=0;
		c1=0;
		c2=0;
		decrypt(input_location, "nvsnavunsauv.txt", line);
		
		fin3.open("nvsnavunsauv.txt", ios::in);
		fin3.seekg(0, ios::end);
		if(!fin3||(fin3.tellg()==0))
		{
			cerr<<"The output file did not open";
			Sleep(1000); //Animation
			exit(1);
		}
		fin3.clear();
		fin3.seekg(0, ios::beg);
		
		while(fin3>>word)
		{
			for(int i=0; i<strlen(word); i++)
			{
				if(word[i]>=65&&word[i]<=90)
				{
					word[i]+=32;
				}
			}
		}
		fin3.clear();
		fin3.seekg(0, ios::beg);
		
		for(int i=0; i<n_words_part; i++)
		{
			if(cN==n_words_part)
			{
				break;
			}
			if(strlen(partials_list[i])>0)
			{
				while(fin3>>word)
				{
					if(cN==n_words_part)
					{
						break;
					}
					if(strcmp(word, partials_list[i])==0)
					{
						cN++;
						break;
					}
				}
			}
		}
		
		while(fin3>>word)
		{
			if(strlen(word)==1)
			{
				for(int g=0; g<n_terms_1; g++)
				{
					if(strcmp(word, list1[g])==0)
					{
						c1=1;
						break;
					}
				}
			}
		}
		fin3.clear();
		fin3.seekg(0, ios::beg);
		while(fin3>>word)
		{
			if(strlen(word)==2)
			{
				for(int g=0; g<n_terms_2; g++)
				{
					if(b!=g)
					{
						if(c2==1)
						{
							c2=2;
							break;
						}
						else
						{
							b=g;
							c2=1;
						}
					}
				}
			}
		}
		if(strlen(partials)==0)
		{
			if(c1==1&&c2==2)
			{
				Output_Save=line;
				fin.close();
				fin2.close();
				fin3.close();
				remove("nvsnavunsauv.txt");
				return Output_Save;
			}
		}
		else
		{
			if(((c1==1||c2>=1)&&(cN==(n_words_part))))
			{
				Output_Save=line;
				fin.close();
				fin2.close();
				fin3.close();
				remove("nvsnavunsauv.txt");
				return Output_Save;
			}
		}
		fin3.close();
	}
	fin.close();
	fin2.close();
	fin3.close();
	remove("nvsnavunsauv.txt");
	return "!";
}

void typeout(char* input, char time_type, int time_in_ms)
/*
time_type:
	t: total
	i: individual
*/
{
	int len;
	len=strlen(input);
	int t=0;
	if(time_type=='i')
	{
		t=time_in_ms;
	}
	else
	{
		if(time_type=='t')
		{
			t=time_in_ms/len;
		}
	}
	for(int i=0; i<len; i++)
	{
		cout<<input[i];
		Sleep(t);
	}
	return;
}

void gotoXY(int x, int y)
{
	COORD cursor_position;
	cursor_position.X=x;
	cursor_position.Y=y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cursor_position);
	return;
}

char* conv_to_char(int num)
{
	int len=0;
	int num_temp;
	
	while(num/pow(10, len)>0)
	{
		len++;
	}
	
	char num_char[len+1];
	
	for(int i=0; i<len; i++)
	{
		num_temp=num/pow(10, len-i-1);
		num_temp=num_temp%10;
		num_char[i]=char(num_temp + '0');
	}
	num_char[len]='\0';
	
	return num_char;
}

int conv_to_int(char* num_char)
{
	int len=strlen(num_char);
	int num=0;
	
	for(int i=0; i<len; i++)
	{
		num+=int(num_char[i] - '0')*pow(10, len-i-1);
	}
	
	return num;
}
