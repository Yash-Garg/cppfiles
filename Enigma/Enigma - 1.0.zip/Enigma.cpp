//yuhd uv hfdnkkdu uuejo ufndalid hf f eufgne ufn fdbjs jjfuv.
//The above is just random text to check encryption status of the cpp file

#include <iostream>
#include <conio.h>
#include <robot.h>
#include <UID.h>
#include <math.h>
#include <string.h>

using namespace std;

char ver[4]={"1.0"};
char screen_len=79;
char exit_message[10]={"MR. ROBOT"};

char heading[56]={"\t\t<<<----------------ENIGMA------------------>>>\n"};
char version[11]={"[Ver:"};
char selection='\0';
char input[200]={"./"}, output[200]={"./"}, wordlist[200]={"./"}, password[100]={"\0"}, part[100];
char UID[11];


void show_heading(int);
void show_mode(char, int);
void encrypt_file();
void file_selection();
void working(char*, char*);
void decrypt_file();
void developer();
void show_help();
void exit_program();

int main()
{
	if(strlen(version)!=11)
	{
		app_string(version, ver);
		app_string(version, "]\n\n");
	}
	
	show_heading(1);
	MAIN:
	show_heading(0);
	cout<<"1: Encrypt a File\n";
	cout<<"2: Decrypt a File\n";
	cout<<"3: Developer Mode\n";
	cout<<"4: Help (recommended for new users)\n";
	cout<<"5: Exit\n::";
	selection=getch();
	cout<<selection;
	cout<<endl;
	
	switch(selection)
	{
		case '1':
			encrypt_file();
			break;
		case '2':
			decrypt_file();
			break;
		case '4':
			show_help();
			break;
		case '3':
			developer();
			break;
		case '5':
			exit_program();
			break;
		default:
			cout<<"\nInvalid Selection\nPress any key to Retry....\n";
			getch();
			break;
	}
	
	goto MAIN;
	
	return 0;
}

void show_heading(int animation)
{
	system("cls");
	switch(animation)
	{
		case 0:
			cout.write(heading, strlen(heading));
			cout.write(version, strlen(version));
			break;
		case 1:
			typeout(heading, 't', 1000);
			typeout(version, 't', 300);
			Sleep(500);
			break;
	}
	
	
	return;
}

void show_mode(char mode, int animation)
{
	char title[20];
	char cout_arr[80];
	switch(mode)
	{
		case 'e':
			strcpy(title, "// ENCRYPTION //");
			break;
		case 'd':
			strcpy(title, "// DECRYPTION //");
			break;
		case 'v':
			strcpy(title, "// DEVELOPER //");
			break;
		case 'h':
			strcpy(title, "// HELP //");
			break;
		default:
			strcpy(title, "\0");
			break;
	}
	
	switch(animation)
	{
		case 0:
			cout.write(title, strlen(title));
			cout<<"\n\n";
			break;
		case 1:
			int i=0, j=0, k=0;
			for(j=0; j<strlen(title); j++)
			{
				if(title[j]==' ')
				{
					continue;
				}
				if(j-1>=0)
				{
					cout_arr[j]=title[j];
				}
				for(i=j; i<screen_len; i++)
				{
					for(k=j; k<screen_len-i-1; k++)
					{
						cout_arr[k]=' ';
					}
					cout_arr[k]=title[j];
					k++;
					for(; k<screen_len; k++)
					{
						cout_arr[k]=' ';
					}
					cout<<cout_arr<<'\r'<<flush;
						Sleep(1);
				}
			}
			cout<<endl<<endl;
			break;
	}
	
	return;
}

void encrypt_file()
{
	show_heading(0);
	show_mode('e', 1);
	
	file_selection();
	for(int i=0; i<100; i++)
	{
		password[i]='\0';
	}
	
	typeout("Enter a PassKey for Encryption: ", 't', 1500);
	
	pass_entry(password, 0, 99);
	cout<<endl<<endl;
	
	CHECK_ENCRYPT:
	typeout("Are you sure (y/n): ", 't', 1000);
	selection=getch();
	cout<<selection;
	switch(selection)
	{
		case 'y':
			encrypt(input, output, password);
			working("Encrypting File...", "OK");
			break;
		case 'n':
			for(int i=0; i<100; i++)
			{
				password[i]='\0';
			}
			for(int i=0; i<200; i++)
			{
				input[i]='\0';
			}
			for(int i=0; i<200; i++)
			{
				output[i]='\0';
			}
			break;
		default:
			cout<<"\nInvalid Selection\nPress any key to Retry....\n";
			getch();
			goto CHECK_ENCRYPT;			
	}
	
	
	cout<<endl<<"Press any Key to Return to Menu\n";
	getch();
	return;
}

void file_selection()
{
	INPUT:
	for(int i=0; i<200; i++)
	{
		input[i]='\0';
	}
	input[0]='.';
	input[1]='/';
	
	typeout("::Select Input File::", 't', 1500);
	cout<<"\n";
	Sleep(250);
	strcpy(input, select_file(input, 1));
	cout<<endl<<"Input File: "<<endl<<'\t';
	cout.write(input, strlen(input));
	cout<<endl<<endl;
	
	OUTPUT:
	for(int i=0; i<200; i++)
	{
		output[i]='\0';
	}
	output[0]='.';
	output[1]='/';
	
	typeout("::Select Output File::", 't', 1500);
	cout<<"\n";
	Sleep(250);
	strcpy(output, select_file(output, 1));
	cout<<endl<<"Output File: "<<endl<<'\t';
	cout.write(output, strlen(output));
	cout<<endl<<endl;
	
	return;
}

void working(char* default_msg, char* end_msg)
{
	char display[200], display_clear[200];
	
	int i=0;
	for(int counter=0; counter<280; counter++)
	{
		for(i=0; i<strlen(default_msg); i++)
		{
			display[i]=default_msg[i];
		}
		display[i]='[';
		i++;
		display[i]=' ';
		i++;
		switch(counter%4)
		{
			case 0:
				display[i]='|';
				break;
			case 1:
				display[i]='/';
				break;
			case 2:
				display[i]='-';
				break;
			case 3:
				display[i]='\\';
				break;			
		}
		i++;
		display[i]=' ';
		i++;
		display[i]=']';
		i++;
		
		cout.write(display, i);
		cout<<'\r'<<flush;
		Sleep(10);
	}
	
	for(i=0; i<strlen(default_msg); i++)
	{
		display[i]=default_msg[i];
	}
	display[i]='[';
	i++;
	for(int j=0; j<strlen(display); j++, i++)
	{
		display[i]=end_msg[j];
	}
	cout<<"\r                                                                            "<<flush;
	cout<<'\r'<<display;
	cout<<"]";
	cout<<endl;
	Sleep(250);
	return;
}

void decrypt_file()
{
	show_heading(0);
	show_mode('d', 1);
	
	file_selection();
	
	typeout("Enter PassKey for Decryption: ", 't', 1500);
	
	pass_entry(password, '*', 99);
	cout<<endl<<endl;
	
	CHECK_DECRYPT:
	typeout("Are you sure (y/n): ", 't', 1000);
	selection=getch();
	cout<<selection;
	switch(selection)
	{
		case 'y':
			decrypt(input, output, password);
			working("Decrypting File...", "OK");
			break;
		case 'n':
			for(int i=0; i<100; i++)
			{
				password[i]='\0';
			}
			for(int i=0; i<200; i++)
			{
				input[i]='\0';
			}
			for(int i=0; i<200; i++)
			{
				output[i]='\0';
			}
			break;
		default:
			cout<<"\nInvalid Selection\nPress any key to Retry....\n";
			getch();
			goto CHECK_DECRYPT;			
	}
	
	cout<<endl<<"Press any Key to Return to Menu\n";
	getch();
	return;
}

void developer()
{
	strcpy(UID, UID_Gen());
	
	
	char UID_check[11], line[200];
	fstream fin;
	
	DEV_CHECK:
	show_heading(0);
	show_mode('v', 0);
	typeout("Enter UID: ", 't', 1000);
	cin.getline(UID_check, 11);
	
	if(strcmp(UID, UID_check)==0)
	{
		show_heading(0);
		show_mode('v', 1);
		DEV_FUNCTIONS:
		show_heading(0);
		show_mode('v', 0);
		cout<<"1: Decrypt CPP File for editing\n";
		cout<<"2: Re-Encrypt CPP File\n";
		cout<<"3: Password Recovery Mode\n";
		cout<<"4: Go Back\n::";
		selection=getch();
		cout<<selection;
		cout<<endl;
		cout<<endl;
		switch(selection)
		{
			case '1':
				fin.open("Enigma.cpp", ios::in);
				fin.getline(line, 200);
				fin.close();
				if(strcmp(line, "//yuhd uv hfdnkkdu uuejo ufndalid hf f eufgne ufn fdbjs jjfuv.")==0)
				{
					cout<<"File is already Decrypted\nPress any key to continue....\n";
					getch();
					goto DEV_FUNCTIONS;
				}
				else
				{
					decrypt("Enigma.cpp", "Enigma.cpp", "hruwn289475cqyrciuy");
					working("Decrypting File...", "OK");
					cout<<endl<<"Press any key to continue\n";
					getch();
					goto DEV_FUNCTIONS;
				}
				break;
			case '2':
				fin.open("Enigma.cpp", ios::in);
				fin.getline(line, 200);
				fin.close();
				if(strcmp(line, "//yuhd uv hfdnkkdu uuejo ufndalid hf f eufgne ufn fdbjs jjfuv.")!=0)
				{
					cout<<"File is already Encrypted\nPress any key to continue....\n";
					getch();
					goto DEV_FUNCTIONS;
				}
				else
				{
					encrypt("Enigma.cpp", "Enigma.cpp", "hruwn289475cqyrciuy");
					working("Encrypting File...", "OK");
					cout<<endl<<"Press any key to continue\n";
					getch();
					goto DEV_FUNCTIONS;
				}
				break;
			case '3':
				cout<<endl;
				
				file_selection();
				for(int i=0; i<200; i++)
				{
					wordlist[i]='\0';
				}
				wordlist[0]='.';
				wordlist[1]='/';
				typeout("::Select the Wordlist file::", 't', 1500);
				strcpy(wordlist, select_file(wordlist, 1));
				cout<<endl<<"Wordlist file: "<<wordlist<<endl<<endl;
				
				Partials:
				cout<<"Please enter the word(s) that are present in the file"<<endl;
				cout<<"[Leave blank if unknown]: "<<endl;
				cout<<"Please seperate the words with a ';' character: "<<endl<<endl;
				cout<<"\t";
				cin.ignore();
				gets(part);
				strcpy(PassKey, decrypt_brute(input, wordlist, part));
				cout<<endl;
				if(strcmp(PassKey, "!")==0)
				{
					working("Breaking PassKey...", "NO");
					
					cout<<"Try with another wordlist"<<endl;
				}
				else
				{
					if(strcmp(PassKey, "#")==0)
					{
						cout<<"The Minimum length of a word must be 4";
						cout<<endl<<"Please Re-enter";
						cout<<endl<<endl;
						goto Partials;
					}
					else
					{
						working("Breaking PassKey...", "OK");
						cout<<endl<<endl<<"Workable PassKey found: "<<PassKey<<endl<<endl;
						Sleep(2000);
						decrypt(input, output, PassKey);
						cout<<"Please check the output file"<<endl;
						cout<<"If the result is not as expected, try making the above key a comment in the wordlist"<<endl;
						cout<<"Achieve this by adding \"//\" before the key"<<endl<<endl;
					}
				}
				Sleep(500);
				cout<<endl<<"Press any key to continue...\n";
				getch();
				goto DEV_FUNCTIONS;
				break;
			case '4':
				break;
			default:
				cout<<"\nInvalid Selection\nPress any key to Retry....\n";
				getch();
				goto DEV_FUNCTIONS;
		}
	}
	else
	{
		cout<<endl<<endl;
		cout<<"Invalid UID!\nPress any key to continue....\n";
		getch();
		return;
	}
	return;
}

void show_help()
{
	show_heading(0);
	show_mode('h', 1);
	
	cout<<"This Version of the program is a Beta Version\nNew Help section for this program is currently being written\n";
	cout<<"Press any key to continue..\n";
	getch();
	
	return;
}

void exit_program()
{
	char exit_msg[]={"ENCRYPTED"};
	int len=sqrt(strlen(exit_msg));
	len+=len-1;
	char exit_message_1[len][len];
	int pos_x, pos_y;
	int flag=1;
	
	char out_char[strlen(exit_message)/3+3];
	cout<<endl<<endl;
	int pos, pos_1, pos_2;
	pos_1=strlen(exit_message)/2+1;	//if len is odd, formula is valid. if even, it is one of the two possible values of the answer
	pos_2=screen_len/2+1;	//if len is odd, formula is valid. if even, it is one of the two possible values of the answer
	pos=pos_2-pos_1;
	for(int i=0; i<pos-1; i++)
	{
		cout<<" ";
	}
	
	int m=0, z=0;
	for(int h=0; h<strlen(exit_message)/3+3; h++)
	{
		out_char[h]='\0';
	}
	for(m=0, z=0; z<strlen(exit_message)/3; m++, z++)
	{
		out_char[m]=exit_message[z];
	}
	typeout(out_char, 'i', 100);
	Sleep(150);
	for(int h=0; h<strlen(exit_message)/3+3; h++)
	{
		out_char[h]='\0';
	}
	for(m=0; z<2*strlen(exit_message)/3; m++, z++)
	{
		out_char[m]=exit_message[z];
	}
	typeout(out_char, 'i', 250);
	Sleep(300);
	for(int h=0; h<strlen(exit_message)/3+3; h++)
	{
		out_char[h]='\0';
	}
	for(m=0; z<strlen(exit_message); m++, z++)
	{
		out_char[m]=exit_message[z];
	}
	typeout(out_char, 'i', 25);
	
	cout<<endl<<endl;
	Sleep(1000);
	
	for(int m=52; m>=0; m--)
	{
		int k=0, m_2=m%26;
		for(int i=0; i<len; i++)
		{
			for(int j=0; j<len; j++)
			{
				if(exit_msg[k]-m_2>='A')
				{
					exit_message_1[i][j]=exit_msg[k]-m_2;
				}
				else
				{
					exit_message_1[i][j]=exit_msg[k]-m_2+26;
				}
				j++;
				exit_message_1[i][j]=' ';
				k++;
			}
			i++;
			for(int j=0; j<len; j++)
			{
				exit_message_1[i][j]=' ';
			}
		}
		
		for(int i=0; i<len; i++)
		{
			cout<<"\t\t\t\t    ";
			for(int j=0; j<len; j++)
			{
				cout<<exit_message_1[i][j];
			}
			cout<<"\n";
		}
		
		if(flag)
		{
			CONSOLE_SCREEN_BUFFER_INFO cur_pos;
			GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cur_pos);
			pos_x=cur_pos.dwCursorPosition.X;
			pos_y=cur_pos.dwCursorPosition.Y-len;
			flag=0;
		}
		if(m!=0)
		{
			gotoXY(pos_x, pos_y);
		}
		Sleep(75);
	}
	
	for(int i=0; i<3; i++)
	{
		CONSOLE_SCREEN_BUFFER_INFO cur_pos;
		GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cur_pos);
		int pos_x=cur_pos.dwCursorPosition.X;
		int pos_y=cur_pos.dwCursorPosition.Y-len;
		
		gotoXY(pos_x, pos_y);
		
		for(int m=0; m<len; m++)
		{
			cout<<"\r                                                                 \n";
		}
		
		Sleep(100);
		
		if(i!=3)
		{
			gotoXY(pos_x, pos_y);
		}
		
		for(int j=0; j<len; j++)
		{
			cout<<"\t\t\t\t    ";
			for(int l=0; l<len; l++)
			{
				cout<<exit_message_1[j][l];
			}
			cout<<"\n";
		}
		
		Sleep(300);
	}
	

	
	Sleep(4000);
	
	exit(0);
	
	return;
}
